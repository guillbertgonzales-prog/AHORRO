import { createHash } from 'node:crypto';

// Scheduled Appwrite Function. No public HTTP endpoint or browser-side send key.
const APP_ID='5c87d3f0-7850-4345-80bf-869d64e581b3';
const START_ROW='baseline-v1';
const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export function eventIdentity(value){
 const bytes=createHash('sha256').update(value).digest().subarray(0,16);
 bytes[6]=(bytes[6]&15)|64;bytes[8]=(bytes[8]&63)|128;
 const hex=bytes.toString('hex');
 return `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20)}`;
}
export function movements(state){
 if(!state||!Array.isArray(state.entries)||!Array.isArray(state.goals)||(state.withdrawals!==undefined&&!Array.isArray(state.withdrawals)))throw Error('SOURCE_INVALID');
 const seen=new Set();const events=[];
 for(const [kind,items] of [['deposito',state.entries],['retiro',state.withdrawals||[]]]){
  const counts=new Map();
  for(const item of items){
   if(!item||!Number.isFinite(Number(item.amount))||Number(item.amount)<=0||!Number.isFinite(Date.parse(item.date)))throw Error('MOVEMENT_INVALID');
   // Old records have no ID. Amount is deliberately excluded to ignore corrections.
   const base=JSON.stringify([item.date,item.person||'',item.goalId||'original']);
   const count=(counts.get(base)||0)+1;counts.set(base,count);
   const identity=item.id?`${kind}:id:${item.id}`:`${kind}:legacy:${base}:${count}`;
   const id=eventIdentity(identity);
   if(seen.has(id))continue;seen.add(id);
   events.push({id,kind,date:item.date});
  }
 }
 return events;
}
async function jsonRequest(url,options={},fetcher=fetch){
 const response=await fetcher(url,{...options,redirect:'error',signal:AbortSignal.timeout(15000)});
 const body=await response.json().catch(()=>({}));
 if(!response.ok){const error=Error('REMOTE_HTTP_'+response.status);error.status=response.status;throw error}
 return body;
}
export async function run({env,key,fetcher=fetch,now=()=>Date.now()}){
 const required=['ONESIGNAL_API_KEY','PUSH_SUBSCRIPTION_IDS','JSONBIN_ACCESS_KEY'];
 for(const name of required)if(!env[name]?.trim())throw Error('MISSING_'+name);
 const recipients=[...new Set(env.PUSH_SUBSCRIPTION_IDS.split(',').map(x=>x.trim()).filter(Boolean))].sort();
 if(!recipients.length||recipients.length>10||recipients.some(id=>!uuid.test(id)))throw Error('INVALID_RECIPIENTS');
 if(!key)throw Error('MISSING_APPWRITE_DYNAMIC_KEY');
 const endpoint=(env.APPWRITE_FUNCTION_API_ENDPOINT||'https://nyc.cloud.appwrite.io/v1').replace(/\/$/,'');
 const project=env.APPWRITE_FUNCTION_PROJECT_ID||'6adb781a001f6dbb459e';
 const db=env.PUSH_DATABASE_ID||'6adb7ca90026b0626e46';
 const table=env.PUSH_LEDGER_TABLE_ID||'avisos-enviados';
 const bin=env.JSONBIN_BIN_ID||'6adafd99ac6210605a4b0717';
 if(!/^[a-f0-9]{24}$/i.test(bin))throw Error('INVALID_BIN_ID');
 const root=`${endpoint}/tablesdb/${encodeURIComponent(db)}/tables/${encodeURIComponent(table)}/rows`;
 const headers={'X-Appwrite-Project':project,'X-Appwrite-Key':key,'Content-Type':'application/json'};
 const store=(url,options={})=>jsonRequest(url,{...options,headers},fetcher);
 const mark=async id=>{try{await store(root,{method:'POST',body:JSON.stringify({rowId:id,data:{},permissions:[]})})}catch(error){if(error.status!==409)throw error}};
 const saved=new Set();let cursor;
 do{
  const url=new URL(root);
  for(const query of [{method:'limit',values:[100]},{method:'orderAsc',attribute:'$id',values:[]},...(cursor?[{method:'cursorAfter',values:[cursor]}]:[])])url.searchParams.append('queries[]',JSON.stringify(query));
  const page=await store(url);
  if(!Array.isArray(page.rows))throw Error('LEDGER_INVALID');
  page.rows.forEach(row=>saved.add(row.$id));
  cursor=page.rows.length===100?page.rows.at(-1).$id:null;
 }while(cursor);
 const source=await jsonRequest(`https://api.jsonbin.io/v3/b/${bin}/latest`,{headers:{'X-Access-Key':env.JSONBIN_ACCESS_KEY,'X-Bin-Meta':'false'}},fetcher);
 const events=movements(source.record||source);
 if(!saved.has(START_ROW)){
  for(const event of events)await mark(event.id);
  await mark(START_ROW);
  return {status:'baseline_created',historical:events.length,sent:0};
 }
 let sent=0,expired=0;const started=now();
 for(const event of events){
  if(saved.has(event.id))continue;
  // Bound retries to less than OneSignal's 30-day idempotency window.
  if(now()-Date.parse(event.date)>28*86400000){await mark(event.id);expired++;continue}
  if(now()-started>75000)break; // Leave work for the next scheduled execution.
  const title=event.kind==='deposito'?'Nuevo depósito en la alcancía':'Nuevo retiro en la alcancía';
  const result=await jsonRequest('https://api.onesignal.com/notifications',{
   method:'POST',headers:{Authorization:'Key '+env.ONESIGNAL_API_KEY,'Content-Type':'application/json'},
   body:JSON.stringify({
    app_id:APP_ID,target_channel:'push',include_subscription_ids:recipients,
    headings:{en:title,es:title},contents:{en:'Abre tu alcancía para ver el movimiento guardado.',es:'Abre tu alcancía para ver el movimiento guardado.'},
    url:'https://guillbertgonzales-prog.github.io/AHORRO/',
    idempotency_key:event.id,ttl:86400
   })
  },fetcher);
  if(!result.id)throw Error('PUSH_NOT_ACCEPTED');
  // Mark only after acceptance. If this write fails, the same idempotency key
  // makes the following attempt safe, including with concurrent executions.
  await mark(event.id);saved.add(event.id);sent++;
 }
 return {status:'checked',sent,expired};
}
export default async function({req,res,log,error}){
 try{
  const result=await run({env:process.env,key:req.headers['x-appwrite-key']});
  log(JSON.stringify(result));return res.json(result);
 }catch(failure){
  // Never log provider responses, credentials, subscriptions or financial data.
  const code=/^[A-Z0-9_]+$/.test(failure.message)?failure.message:'DELIVERY_FAILED';
  error(code);return res.json({status:'error',code},500);
 }
}
